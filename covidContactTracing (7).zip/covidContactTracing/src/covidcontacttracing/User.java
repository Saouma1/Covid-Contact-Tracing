
package covidcontacttracing;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class User implements Comparable<User> {
    int user_Id;
    String firstName;
    String lastName;
    String gender;
    String dateOfBirth;
    String phoneNumber;
    boolean infected;
    LocalDate date_diagnosis;
    List <Contact> contactUser;
    boolean patientZero;
    
    public User(int user_Id, String firstName, String lastName, String gender, String dateOfBirth, String phoneNumber, boolean infected, LocalDate date_diagnosis) {
        this.user_Id = user_Id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
        this.phoneNumber = phoneNumber;
        this.infected = infected;
        this.date_diagnosis = date_diagnosis;
        this.contactUser = new ArrayList<Contact>();
    }
    public User(){
        
    }

    public void setUser_Id(int user_Id) {
        this.user_Id = user_Id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public boolean setInfected(boolean infected) {
       return true;
    }

    public void setDate_diagnosis(String inDate_diagnosis) {
        date_diagnosis = LocalDate.parse(inDate_diagnosis);
    }

    public void setContactUser(List<Contact> contactUser) {
        this.contactUser = contactUser;
    }
    public boolean setPatientZero(boolean patientZero){
        return true;
    }

    public int getUser_Id() {
        return user_Id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getGender() {
        return gender;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public boolean isInfected() {
        return infected;
    }
    public boolean isPatientZero(){
        return patientZero;
    }

    public LocalDate getDate_diagnosis() {
        return date_diagnosis;
    }

    public List<Contact> getContactUser() {
        return contactUser;
    }
    public void addContact(Contact contact){
        contactUser.add(contact);    
    }


    @Override
    public String toString() {
        return "User{" + "user_Id=" + user_Id + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender + ", dateOfBirth=" + dateOfBirth + ", phoneNumber=" + phoneNumber + ", infected=" + infected + ", date_diagnosis=" + date_diagnosis + ", # contacts: " + contactUser.size() + "\n"+'}';
    }

    @Override
    public int compareTo(User other){
        int value = 0;
        if (user_Id < other.user_Id){
            value = -1;
        }
        else if(user_Id > other.user_Id){
            value = 1;
        }
        return value;
    }

    
    
}
