
package covidcontacttracing;

import bridges.base.GraphAdjListSimple;
import bridges.connect.Bridges;
import bridges.validation.RateLimitException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;


public abstract class CovidContactTracing implements Comparable <User>, Comparator<User>{

   private static final String FILE_NAME = "userss.txt";
   private static final String ContactFileText = "contactss.txt";
   private static ArrayList<User> users = new ArrayList();
   private static int user_Id =0;
   private static  List<User> patientZero = new ArrayList();
    private static List<User> finalUserList = new ArrayList();
    public static void main(String[] args){
    
    
    userListPrint();
    loadContact();
   
    for (int i=0;i<users.size();i++)
    {
        finalUserList.add(users.get(i));  
    }
    for (int i=0;i<patientZero.size();i++)
    {
        finalUserList.add(patientZero.get(i)); 
    }
    System.out.println(finalUserList.size());
    
    System.out.println(users);

    patientZero(patientZero);
    System.out.println(patientZero);
    createBridgesGraph(users, user_Id);

    }
    
    public static String userListPrint(){
        
    
    String firstName= "";
    String lastName= "";
    String gender= "";
    String dateOfBirth= "";
    String phoneNumber= "";
    boolean infected = false;
    LocalDate date_diagnosis;
    List<Contact> userContact = null;
 
    String test = "";
    String line;
    String[] tokens ;
    User user;
 
        try (Scanner fileInput = new Scanner(new File(FILE_NAME)))
        {
            fileInput.nextLine();
            while(fileInput.hasNext())
            {
                line = fileInput.nextLine();
                tokens = line.split(",");
                
                user_Id = Integer.parseInt(tokens[0]);
                firstName = tokens[1];
                lastName =tokens[2];
                gender = tokens[3];
                dateOfBirth = tokens[4];
                phoneNumber = tokens[5];
                if ("yes".equalsIgnoreCase(tokens[6])){
                    infected = true;
                }
                else if("no".equalsIgnoreCase(tokens[6])){
                    infected = false;
                }
                
               if(!infected){
                    date_diagnosis = LocalDate.now();
                    
                }
                else{
                    date_diagnosis = LocalDate.parse(tokens[7]);
                }
                
                user = new User(user_Id,firstName, lastName,gender,dateOfBirth,phoneNumber,infected,date_diagnosis) {};    
                users.add(user); 
                
                
                
                
        if(user.isInfected()== true){
        patientZero.add(user);
      
    
    }
                // if we want to make sure that this is working we can convert the compareTo method (-1) and (1) 
                //so we check if it can print them the other way around
            }
        System.out.println(patientZero.size());
//        System.out.println(patientZero.toString());
 
//            System.out.println(userList.toString());
//            System.out.println(userList.size());   
//          user = getUserById(userList,user.user_Id);
//            System.out.println(user);
        }
        catch (FileNotFoundException exception)
        {
            System.out.println("Error, " + FILE_NAME + " could not be found.");
            System.out.println("More details: " + exception.getMessage());
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("More details: " + e.getMessage());
        }
        
        Collections.sort(users);
        return test;
    }
    
     public static void loadContact(){
       
       Contact contact;
       String text;
       String [] tokens;
       

       try (Scanner fileInput = new Scanner(new File(ContactFileText))){
           fileInput.nextLine();
           while(fileInput.hasNext()){
               text = fileInput.nextLine();
               tokens = text.split(",");
               int repetition = Integer.parseInt(tokens[0]);
               User reportUser = getUserById(users,repetition);
               contact = new Contact();
               contact.setReporting_user(reportUser);
               int c = Integer.parseInt(tokens[1]);
               User cUser =getUserById(users,c);
               
               contact.setContact_user(cUser);
               contact.setContact_start(tokens[2]);
               contact.setContact_end(tokens[3]);
               
//               contact.addContact(contact);
               reportUser.addContact(contact);   
               //System.out.println(user.toString()+"\n");
            
           }
             
       }catch(FileNotFoundException e){    
       }
   }

    public static User getUserById(List <User>userList, int userId)
    {
        User users ;
        users = new User() ;
        users.setUser_Id(userId);
      
        
       int index = Collections.binarySearch(userList, users);
       if(index > -1)
       {
            return userList.get(index);
       }
        else {
           return null;
        }
    }
    
    private static void createBridgesGraph(List<User> users, int graphId)
    {
        // Initialize Bridges, set credentials, title, and description.
        System.out.print("Creating Bridges Graph...");
        Bridges bridges = new Bridges(graphId, "jsaouma", "203445062570");
        bridges.setTitle("Covid User Graph");
        bridges.setDescription("Showing Covid infections in a population.");

        // Create an adjacency-list-based graph
        GraphAdjListSimple<String> graph = new GraphAdjListSimple<>();
        System.out.print("creating verticies...");
        
        // Add users as vertexes in the graph.
        for (User user: finalUserList)
        {
            // The first argument is the id; the second argument is the label to display.
            // Currently BRIDGES ignores the label and displays the id.
            graph.addVertex(user.getFirstName(), user.getFirstName());
        }
         // Add contacts as edges in the graph between vertexes.
        System.out.print("creating edges...");
        Contact contact;
        
        for (User user: finalUserList )
        {
            if (!user.getContactUser().isEmpty())
            {
                contact = user.getContactUser().get(0);
                graph.addEdge(contact.getReporting_user().getFirstName(), 
                    contact.getContact_user().getFirstName(), 
                    // This third argument is the label for the edge, but BRIDGES appears to ignore it.
                    contact.getContact_start().toString());
            }
            if (user.isInfected())
{
    graph.getVertex(user.getFirstName()).setColor("orange");
}
        }

        // Pass the graph object to BRIDGES
        bridges.setDataStructure(graph);

        try
        {
            // Finaly, we call the visualize function
            bridges.visualize();
        }
        catch (IOException | RateLimitException exception)
        {
            System.out.println(exception);
        }

        System.out.println("done.");

}
public static void patientZero(List<User> infected){
  
    User user;
    List<Contact> contacts;
  
   userComparator comparator = new userComparator();
   Collections.sort(users, comparator);
   
   for (int i = 0; i< infected.size();i++){
       
       user = users.remove(0);
       patientZero.add(user);
       user.setPatientZero(true);
       contacts = user.getContactUser();
       
       for(Contact contact : contacts){
           LocalDateTime fifteenMinutesEarlier = contact.getContact_end().minusMinutes(15);
       if (contact.getContact_start().isBefore(fifteenMinutesEarlier)) 
        {
       // We can presume this contact was infected by this user.
       contact.setInfectiousContact(true);
       infected.remove(contact.getContact_user());
        }
           if(contact.getContact_user().isInfected()){
                contact.setInfectiousContact(true);
                infected.remove(contact.getContact_user());

                    }
                }
            }
        }  
    }
    

