
package covidcontacttracing;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class Contact implements Comparable<Contact>{
    
    User reporting_user;
    User contact_user;
    LocalDateTime contact_start;
    LocalDateTime Contact_end;
    boolean infectiousContact;
 private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public Contact(User reporting_user, User contact_user, LocalDateTime contact_start, LocalDateTime Contact_end, boolean infectiousContact) {
        this.reporting_user = reporting_user;
        this.contact_user = contact_user;
        this.contact_start = contact_start;
        this.Contact_end = Contact_end;
        this.infectiousContact = false;
    }
    public Contact(){
        
    }

    public void setReporting_user(User reporting_user) {
        this.reporting_user = reporting_user;
    }

    public void setContact_user(User contact_user) {
        this.contact_user = contact_user;
    }

    public void setContact_start(String contact_start) {
        this.contact_start = LocalDateTime.parse(contact_start, dateTimeFormatter);
       
    }

    public void setContact_end(String Contact_end) {
        this.Contact_end = LocalDateTime.parse(Contact_end, dateTimeFormatter);
    }
    public boolean setInfectiousContact(boolean infectiousContact){
        return true;
    }
  

    public User getReporting_user() {
        return reporting_user;
    }

    public User getContact_user() {
        return contact_user;
    }

    public LocalDateTime getContact_start() {
        return contact_start;
    }

    public LocalDateTime getContact_end() {
        return Contact_end;
    }
    public boolean isInfectiousContact(){
        return true;
    }
   

    @Override
    public String toString() {
        return "Contact{" + "reporting_user=" + reporting_user + ", contact_user=" + contact_user + ", contact_start=" + contact_start + ", Contact_end=" + Contact_end + '}';
    }
    

    @Override
    public int compareTo(Contact c) {
       int value = 0;
       return value;
    }
    
}
