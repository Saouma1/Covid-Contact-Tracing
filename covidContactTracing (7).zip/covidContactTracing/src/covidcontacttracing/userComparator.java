
package covidcontacttracing;

import java.util.Comparator;

public class userComparator implements Comparator<User>{

    @Override
    public int compare(User o1, User o2) {
        
      if(o1.date_diagnosis.compareTo(o2.date_diagnosis)>0){
          return 1;
      }else if(o1.date_diagnosis.compareTo(o2.date_diagnosis)<0){
          return -1;
      }
      else{
          return 0;
      }
    }
      
}
